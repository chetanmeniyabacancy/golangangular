package operations

import (
	_ "github.com/go-openapi/analysis/internal/antest"
)
