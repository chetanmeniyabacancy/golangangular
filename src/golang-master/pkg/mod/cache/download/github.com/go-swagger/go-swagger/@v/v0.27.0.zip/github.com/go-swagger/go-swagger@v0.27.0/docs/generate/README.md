<!--
    Put in this directory CLI generate subcommands reference usage
-->
